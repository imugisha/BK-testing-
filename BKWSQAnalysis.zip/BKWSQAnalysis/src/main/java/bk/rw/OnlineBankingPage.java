package bk.rw;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OnlineBankingPage {
	
	public static boolean isApplyButtonExist() {
		String url ="https://www.bk.rw/ways-of-banking/online-banking";
		
		String btnName = "Apply Now";

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\lngirimana\\workspace\\tools\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(url);
		
		// fetches text from the element and stores it in text
		String actualbtnName = driver.findElement(By.tagName("a")).getText();
		System.out.println("Text present in span : "+ actualbtnName);
		
		
		// clicks the button which has id = 'button'
		String idAttribute = driver.findElement(By.tagName("button")).getAttribute("id");
		System.out.println("Attribute of Id is : "+ idAttribute);
		
		// compare the expected Name of the button with the actual Name of the button and print the result
		if (btnName.equals(actualbtnName)){
			System.out.println("Verification Successful");
		}else{
			System.out.println("Verification Failed - An incorrect button name");
		}
		
		// verify whether button is displayed or not ?
		boolean displayed = driver.findElement(By.xpath("//button[@id='displayed']")).isDisplayed();
		System.out.println("Element Displayed is : "+ displayed);
		
		// fetches text from the element and stores it in text
		//Dimension size = driver.findElement(By.xpath("//button[contains(@class,'btn-primary')]")).getSize();
		
		// return blank as there is no such value
		String nameAttribute = driver.findElement(By.tagName("button")).getAttribute("name");
		System.out.println("Attribute of name is : "+ nameAttribute);

		// compare the expected Name of the button with the actual Name of the button and print the result
		
		if (btnName.equals(actualbtnName)){
			System.out.println("Verification Successful");
		}else{
			System.out.println("Verification Failed - An incorrect button name");
		}
		
		return true;
	}

}
