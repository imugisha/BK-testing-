package bk.rw;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class HomePage {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\lngirimana\\workspace\\tools\\chromedriver.exe");
		
		DesiredCapabilities cap =DesiredCapabilities.chrome();

		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

		WebDriver driver= new ChromeDriver(); // ChromeDriver(cap);
		 
		 driver.get("https://www.bk.rw/");
		 
		 
		 List<WebElement> links = driver.findElements(By.tagName("a"));
		 
		 System.out.println(links.size());
		 
		 for (int i = 1; i<=links.size(); i=i+1){
			 System.out.println(links.get(i).getText());
		 }
		 
		
		 
		
	}

}
