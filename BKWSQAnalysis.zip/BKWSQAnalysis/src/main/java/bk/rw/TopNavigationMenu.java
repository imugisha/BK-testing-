package bk.rw;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TopNavigationMenu {

	
	public static void getWSMainLinks() {

		String srcLink = "Current & Savings";
		 WebDriver driver = new FirefoxDriver();
		 
		 driver.get("https://bk.rw/");
		 
		List<WebElement> links = driver.findElements(By.tagName("a"));

		List<WebElement> dropdown = driver.findElements(By.tagName("select"));  
		  
		 System.out.println(dropdown.size());
		 
		 System.out.println(links.size());
		 
		 for (int i = 1; i<=links.size(); i=i+1){
			 System.out.println(links.get(i).getText());
		 }
		 
		 List<WebElement> linkElements = driver.findElements(By.tagName("a"));

		 String[] linkTexts = new String[linkElements.size()];
		 
		 for (String l : linkTexts) {

			    driver.findElement(By.linkText(l)).click();

			    if (driver.getTitle().equals(srcLink)) {

			        System.out.println("\"" + l + "\""

			        + " is not Working.");
			        				
			        driver.findElement(By.linkText("click here")).click();					
			        System.out.println("title of page is: " + driver.getTitle());

			    } else {

			        System.out.println("\"" + l + "\""

			        + " is working.");

			    }

			    driver.navigate().back();

			}
		 
	}
	
	public static void navigateMenu() {
		String baseUrl = "https://www.bk.rw";					
        System.setProperty("webdriver.chrome.driver","C:\\Users\\lngirimana\\workspace\\tools\\chromedriver.exe");					
        WebDriver driver = new ChromeDriver();					
        		
        driver.get(baseUrl);
        
        WebElement currentAndSavingLink = null;
        
        currentAndSavingLink = driver.findElement(By.linkText("Current & Savings"));
        
        String accountServiceLinkText = null;
        String onlineBankingLinkText= null;
        if(currentAndSavingLink != null) {
        	accountServiceLinkText = driver.findElement(By.partialLinkText("Account Services")).getText();	
        	
        	if(accountServiceLinkText != null) {
        		 System.out.println(accountServiceLinkText);					
                 onlineBankingLinkText = driver.findElement(By.partialLinkText("Online Banking")).getText();		
                 if(onlineBankingLinkText != null){
                	 System.out.println(onlineBankingLinkText);
                	 /* Check if the link is enabled */
                 }
        	}
        }else {
        	System.out.println("The Current & Savings link does not exists!!");
        }
        driver.quit();			
	}
	
	public static void main(String[] args) {
		navigateMenu();
	}

}
